<html>
   
   <head>
      <title>Sending HTML email using PHP</title>
   </head>
   
   <body>
      
      <?php
         $to = "vishakharrumale@gmail.com";
         $subject = "This is subject";
         
         $message = "<b>This is HTML message.</b>";
         
      $retval = mail ($to,$subject,$message,"From:vishakharrumale@gmail.com");
         
         if( $retval == true ) {
            echo "Message sent successfully...";
         }else {
            echo "Message could not be sent...";
         }
      ?>
      
   </body>
</html>