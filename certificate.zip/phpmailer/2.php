<?php
mail ("vishakharrumale@gmail.com","hi","msg","From:vishakharrumale@gmail.com");
?>      