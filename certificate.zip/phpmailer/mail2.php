<?php
define('EMAIL', 'vishakharrumale@gmail.com');
define('PASS', 'Guddi123');


require 'PHPMailerAutoload.php';

$mail = new PHPMailer;                              // Passing `true` enables exceptions
try 
{
    //Server settings
    $mail->SMTPDebug = 2;                                 // Enable verbose debug output
    $mail->isSMTP();                                      // Set mailer to use SMTP
    $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                               // Enable SMTP authentication
    $mail->Username = EMAIL;                 // SMTP username
    $mail->Password = PASS;                           // SMTP password
    $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 587;                                    // TCP port to connect to

    //Recipients
    $mail->setFrom('vishakharrumale@gmail.com', 'vishakharrumale');
    $mail->addAddress('vaishalimore1810@gmail.com', 'vaishalimore1810');     // Add a recipient
    $mail->addAddress('rutuja.raut@viit.ac.in', 'rutuja');     // Add a recipient
     $mail->addAddress('vishakha.umale@viit.ac.in', 'vishakha');     // Add a recipient
    $mail->addAddress('amit818095@gmail.com', 'amit');     // Add a recipient
   $mail->addReplyTo('vaishalimore1810@gmail.com', 'Information');
    $mail->setFrom('vishakharrumale@gmail.com', 'vishakharrumale');
   
  $mail->addReplyTo('vishakharrumale@gmail.com', 'v');
    $mail->addCC('vishakharrumale@gmail.com','cc');
    $mail->addBCC('vishakharrumale@gmail.com','bc');

    // $mail->addCC('cc@example.com');
    // $mail->addBCC('bcc@example.com');

    //Attachments
    // $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
    // $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name

    //Content
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = $_POST['subject'];
    $mail->Body    = 'Please download your certificate from this website <b><a href="www.google.com">feedback link</a></b>';
    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    $mail->send();
    echo 'Message has been sent';
} catch (Exception $e) {
    echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
}

?>