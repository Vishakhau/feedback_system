<?php
require 'PHPMailerAutoload.php';

$mail = new PHPMailer;                              // Passing `true` enables exceptions
try 
{
    //Server settings
    $mail->SMTPDebug = 2;                                 // Enable verbose debug output
    $mail->isSMTP();                                      // Set mailer to use SMTP
    $mail->Host = 'mail.qjtechnologies.com';  // Specify main and backup SMTP servers
    $mail->SMTPAuth = true;                               // Enable SMTP authentication
    $mail->Username = 'elektraa@qjtechnologies.com'; 
                    // SMTP username
    $mail->Password = 'elektraa@123';  
    //$mail->Password = 'Guddi123';                           // SMTP password
    $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 587;                                    // TCP port to connect to

    //Recipients
    $mail->setFrom('elektraa@qjtechnologies.com', 'vishakharrumale');
    // $mail->addAddress('info@qjtechnologies.com', 'QJTECH');     // Add a recipient
   
   // $mail->addAddress('rinank14surwade@gmail.com', 'rina');     // Add a recipient
    $mail->addAddress('rutuja.raut@viit.ac.in', 'rutuja');     // Add a recipient
     $mail->addAddress('vishakha.umale@viit.ac.in', 'vishakha'); 
         // Add a recipient
     // $mail->addReplyTo('info@qjtechnologies.com', 'QJTECH');
    // $mail->addCC('cc@example.com');
    // $mail->addBCC('bcc@example.com');

    //Attachments
    // $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
   $mail->addAttachment('certificate.png', 'certificate.png');    // Optional name

    //Content
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'mail sent via localhost';
    $mail->Body    = 'Please download your certificate from this  <b><a href="#">feedback link</a></b>';
    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    $mail->send();
    echo 'Message has been sent';
} catch (Exception $e) {
    echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
}

?>