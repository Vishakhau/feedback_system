<?php
 define('EMAIL', 'elektraa@qjtechnologies.com');
 define('PASS', 'elektraa@123');
// define('EMAIL', 'vishakharrumale@gmail.com');
// define('PASS', 'Guddi123');

require 'PHPMailerAutoload.php';

$mail = new PHPMailer;                              // Passing `true` enables exceptions
try 
{
    //Server settings
    $mail->SMTPDebug = 4;                                 // Enable verbose debug output
    $mail->isSMTP();                                      // Set mailer to use SMTP
   $mail->Host = 'mail.qjtechnologies.com';  // Specify main and backup mail servers
    
    $mail->SMTPAuth = true;                               // Enable SMTP authentication
    $mail->Username = EMAIL;                 // SMTP username
    $mail->Password = PASS;                           // SMTP password
    $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 26; 
    // $mail->Port = 465; 
    //26
                                       // TCP port to connect to
  $to = $_POST['to'] ;   
  $subject = $_POST['subject']; 
  $message = $_POST['Message'] ;
  
   //Recipients
//    $mail->setFrom('elektraa@qjtechnologies.com', 'QJTECH');
      $mail->setFrom('elektraa@qjtechnologies.com', 'QJTECH');
       
  $mail->addReplyTo('elektraa@qjtechnologies.com', 'QJTECH');
     $mail->addCC('elektraa@qjtechnologies.com', 'QJTECH');
     $mail->addBCC('elektraa@qjtechnologies.com', 'QJTECH');

    // $mail->addAddress('info@qjtechnologies.com', 'QJTECH');     // Add a recipient
   
    $mail->addAddress($to, 'name');     // Add a recipient

  //   $headers .= "Reply-To: The Sender vishakharrumale@gmail.com\r\n";
  // $headers .= "Return-Path: The Sender <vishakharrumale@gmail.com>\r\n";
  // $headers .= "From: The Sender <senter@sender.com>\r\n";

    // 

        // Add a recipient
     // $mail->addReplyTo('info@qjtechnologies.com', 'QJTECH');
    // $mail->addCC('cc@example.com');
    // $mail->addBCC('bcc@example.com');

    //Attachments
    // $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
   // $mail->addAttachment('certificate.png', 'certificate.png');    // Optional name

    //Content
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = $subject;
    $mail->Body    = $message;
    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    $mail->send();
    echo 'Message has been sent';
} catch (Exception $e) {
    echo 'Message could not be sent. Mailer Error: ', $mail->ErrorInfo;
}

?>