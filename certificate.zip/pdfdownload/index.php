<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Simple Example of PDF file using PHP and MySQL</title>
<title>JS Bin</title>
<link rel="stylesheet" type="text/css" href="style.css">
<!--  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
 -->
<!--[if IE]>
  <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
</head>
<body>
<!-- <script type="text/javascript">
     function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#blah')
                        .attr('src', e.target.result)
                        .width(320)
                        .height(320);
                };

                reader.readAsDataURL(input.files[0]);
            }
        }
  </script>
 -->
<div class="header">
    <h2>Download Certificate</h2>
  </div>
  
 <form class="form-inline" method="post" action="c.php">
    <div class="input-group">
      <label>Enter name</label>
      <input type="text" class="form-control" name="name">
    </div>
    <div class="input-group">
      <label>Enter X</label>
      <input type="text" class="form-control" name="x">
    </div>
    <div class="input-group">
      <label>Enter Y</label>
      <input type="text" class="form-control" name="y"> 
    </div> 
      <div class="input-group">
      <input name="img" type='file' class="btn" onchange="readURL(this);" /> 
     </div>

    <div class="input-group">
      <button type="submit" id="pdf" class="btn" name="generate_pdf" class=".btn">
  Download certificate</button>
    </div>
    
  </form>
<!-- 
<div class="container">
 <h2>Download certificate </h2>
  <br><br><br><br>
    <div class="panel panel-primary">
      		<div class="panel-heading">Download certificate</div>
      <div class="panel-body">

		<form class="form-inline" method="post" action="c.php">
			<br>
       Enter name <input type="text" class="form-control" name="name">        <br><br>
     
      Enter x <input type="text" class="form-control" name="x">        <br><br>
      Enter y <input type="text" class="form-control" name="y">         <br><br>
       <input name="img" type='file' onchange="readURL(this);" />      <br><br>

   <img id="blah" src="#" alt="your image" />  <br><br>
 
    <button type="submit" id="pdf" name="generate_pdf" class="btn btn-success">
		<i class="fa fa-pdf"" aria-hidden="true"></i>
		Download certificate</button>
		</form>
   </div>
    </div>

<div class="container" style="padding-top:50px">
<h2>Download certificate PDF file </h2>
<form class="form-inline" method="post" action="c.php">
<button type="submit" id="pdf" name="generate_pdf" class="btn btn-primary"><i class="fa fa-pdf"" aria-hidden="true"></i>
Download certificate</button>
</form>
</fieldset>
</div>
 -->
</body>
</html>