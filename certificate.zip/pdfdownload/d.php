<?php

include_once('fpdf.php');
$yourname = $_POST['name'];
// $date = "06 Dec 2018";
// $pos = "2nd";
$img=$_POST['img'];
$image = imagecreatefrompng($img);
imagealphablending($image, true);

$red = imagecolorallocate($image, 0,0, 10);

// imagefttext("Image", "Font Size", "Rotate Text", "x Left Position", "y Top Position", "Font Color", "Font Name", "Text To Print");
$x=$_POST['x'];

$y=$_POST['y'];


	imagefttext($image, 30, 0, $x,$y, $red, 'mono.ttf', $yourname);


//  if you want to save the file in the web server 


 $filename = 'certificate3.png';
 Imagepng($image, $filename);
 imagedestroy($image);

class PDF extends FPDF
{
// Page header
function Header()
{
    // Logo
    //$this->Image('certificate3.png',20,20,180);
    $this->Image('certificate3.png',0,0,210,297);//co-ordinates for full page size a4 size 0,0,210,297
    $this->SetFont('Arial','B',13);
    // Move to the right
   // $this->Cell(100);
}

}

$pdf = new PDF();
//header
$pdf->AddPage();
//foter page
$pdf->AliasNbPages();
$pdf->SetFont('Arial','B',12);
$pdf->SetDisplayMode('fullpage');
//$pdf->Ln();
// $pdf->fetch();
// $dir='C:\wamp64\www\pdfdownload';
// $filename= "filename.pdf";
//$pdf->Cell($x,$y,$yourname);
//$content=
echo "download";



$path="C:\wamp64\www\pdfdownload";
$filename= "$yourname.pdf";
$fullpath=$path . '\.' . $filename;
$pdf ->Output("$fullpath","F");
// $pdf ->Output();
echo "Saved PDF in location $fullpath";
echo"download from <a href='d.php'>here</a>";


// echo "Save PDF in folder1";
// $mysqli=new mysqli("localhost", "root", "", "test");
// echo "Save PDF in folder2";
// $stmt = $mysqli->prepare("INSERT INTO pdfs2 (pdf) VALUES (?)");
// echo "Save PDF in folder3";
// $stmt->bind_param('s', $pdfcontent);
// echo "Save PDF in folder3";
// $stmt->execute();
// echo "Save PDF in folder4";

?>